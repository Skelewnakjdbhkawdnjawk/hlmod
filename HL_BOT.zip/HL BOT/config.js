module.exports = exports = {
    token: 'MTAwNTczMDY4NzA4MjU2OTgxOA.Gq1a9y.spCHPf3qb3vsrCY3vpWFr0d3Jj2BOrhsOCh7ec', // your bot token
    clientId: '1005730687082569818', // your bot client id
    guildId: '890759609378275469', // the guild id for your slash commands
    globalSlash: true, // if you want to use slash commands globally (true = global, false = guild)

    logsGuildId: '890759609378275469', // the guild id for your bot logs
    logsChannel: '984429882257866792', // the channel id for the logs channel
}